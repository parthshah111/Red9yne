CREATE VIEW dbo.Join_Payment_Billing
AS
SELECT        dbo.Billing_ID.Billing_City, dbo.Billing_ID.Billing_State, dbo.Billing_ID.Billing_Zip, dbo.Billing_ID.Billing_Country, dbo.Payment_Information.Payment_History, dbo.Payment_Information.Order_Deposit, 
                         dbo.Payment_Information.Payment_FName, dbo.Payment_Information.Payment_LName, dbo.Payment_Information.Amount_Due, dbo.Billing_ID.Billing_Address
FROM            dbo.Billing_ID INNER JOIN
                         dbo.Payment_Information ON dbo.Billing_ID.Payment_ID = dbo.Payment_Information.Payment_ID
go

