CREATE VIEW dbo.[Join of Appointment__Customer__PaymentInformation__AppointmentCustomer]
AS
SELECT        dbo.Appointment.Appointment_Date, dbo.Customer.CUSTOMER_FNAME, dbo.Customer.CUSTOMER_LNAME, dbo.Payment_Information.Amount_Due, dbo.Appointment_Customer.App_Cus_ID
FROM            dbo.Payment_Information INNER JOIN
                         dbo.Customer ON dbo.Payment_Information.Customer_ID = dbo.Customer.CUSTOMER_ID INNER JOIN
                         dbo.Appointment_Customer ON dbo.Customer.CUSTOMER_ID = dbo.Appointment_Customer.Customer_ID INNER JOIN
                         dbo.Appointment ON dbo.Appointment_Customer.Appointment_ID = dbo.Appointment.Appointment_ID
go

