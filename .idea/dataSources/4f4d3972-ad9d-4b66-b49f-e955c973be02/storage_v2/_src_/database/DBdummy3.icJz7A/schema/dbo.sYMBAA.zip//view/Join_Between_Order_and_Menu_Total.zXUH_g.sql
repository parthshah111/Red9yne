CREATE VIEW dbo.[Join Between Order and Menu_Total]
AS
SELECT        dbo.[Order].Order_no, dbo.Menu_Total.Food_ID, dbo.Menu_Total.Food_Qty, dbo.Menu_Total.Food_Total
FROM            dbo.[Order] INNER JOIN
                         dbo.Menu_Total ON dbo.[Order].FoodMenu_ID = dbo.Menu_Total.FoodMenu_ID
go

